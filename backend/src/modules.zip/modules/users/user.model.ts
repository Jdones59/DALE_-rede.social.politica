import mongoose from 'mongoose';
import { generateAnonName } from '../../utils/generateAnonName';

const userSchema = new mongoose.Schema({
  realName: { type: String, required: true },
  anonName: { type: String, default: generateAnonName },
  password: { type: String, required: true },
  friends: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  avatar: { type: String, default: '' },
});

export const User = mongoose.model('User', userSchema);