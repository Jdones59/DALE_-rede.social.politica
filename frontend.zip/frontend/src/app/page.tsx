export default function Home() {
return (
<div>
<h1 className="text-3xl font-bold">DebateLigs</h1>
<p className="text-gray-600">Discussões sobre leis e debates legislativos.</p>
</div>
);
}