import mongoose from 'mongoose';

const voteSchema = new mongoose.Schema({
  law: { type: mongoose.Schema.Types.ObjectId, ref: 'Law' },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  vote: { type: Boolean, required: true },  // true: for, false: against
}, { unique: ['law', 'user'] });

export const Vote = mongoose.model('Vote', voteSchema);