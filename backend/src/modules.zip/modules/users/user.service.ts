import { User } from './user.model';
import { Comment } from '../comments/comment.model';
import { Law } from '../laws/law.model';
import { Debate } from '../debates/debate.model';

export const getUserById = async (id: string) => {
  return User.findById(id).select('-password');
};

export const updateUser = async (id: string, data: any) => {
  return User.findByIdAndUpdate(id, data, { new: true }).select('-password');
};

export const getCommentedLaws = async (userId: string) => {
  const lawIds = await Comment.distinct('law', { user: userId });
  return Law.find({ _id: { $in: lawIds } });
};

export const getDebatesByUser = async (userId: string) => {
  return Debate.find({ $or: [{ user1: userId }, { user2: userId }] }).populate('law');
};