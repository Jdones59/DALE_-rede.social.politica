import { Request, Response } from 'express';
import * as userService from '../users/user.service';
import { authMiddleware } from '../../utils/authMiddleware';

export const getMe = async (req: Request, res: Response) => {
  const user = await userService.getUserById((req as any).user.id);
  res.json(user);
};

export const updateProfile = async (req: Request, res: Response) => {
  const updated = await userService.updateUser((req as any).user.id, req.body);
  res.json(updated);
};

export const getUser = async (req: Request, res: Response) => {
  const user = await userService.getUserById(req.params.id);
  res.json(user);
};